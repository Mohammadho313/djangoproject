from django.db import models
import uuid

